# RuView original firmware — ESP32 DevKit V1 port

This directory is based on the original RuView `firmware/esp32-csi-node` source from the uploaded source archive. It is **not** a replacement Arduino sketch.

## Target
- Classic/original ESP32 (ESP32-WROOM/DevKit V1), not ESP32-S3/C3/C6.
- 4 MB flash configuration.
- 2.4 GHz Wi-Fi CSI capture.
- No TFT, no NRF24, no display driver.
- RuView ADR-018 CSI UDP stream remains the output path.

## Important
The upstream firmware defaults to ESP32-S3. This port adds `sdkconfig.defaults.esp32-devkit-v1` with `CONFIG_IDF_TARGET="esp32"` and disables the S3/C6/display LED path. The classic ESP32 CSI driver uses the legacy CSI configuration path already present in `csi_collector.c`. Espressif documents CSI configuration and callback support for the classic ESP32.

## Build
Use an ESP-IDF environment compatible with the source tree. From this directory:

    idf.py set-target esp32
    copy sdkconfig.defaults.esp32-devkit-v1 to sdkconfig.defaults  (Windows)
    idf.py reconfigure
    idf.py build

Then flash/monitor with the normal ESP-IDF commands.

## Not claimed yet
A compiled ESP32 binary has **not** been hardware-verified in this environment. The final `.bin` must be produced by ESP-IDF for target `esp32`; do not flash the upstream S3 binary onto a classic ESP32.
