@echo off
echo STARTING > C:\Users\ruv\idf_test.txt
set IDF_PATH=C:\Users\ruv\esp\v5.4\esp-idf
set PATH=C:\Espressif\tools\python\v5.4\venv\Scripts;C:\Espressif\tools\xtensa-esp-elf\esp-14.2.0_20241119\xtensa-esp-elf\bin;C:\Espressif\tools\cmake\3.30.2\bin;C:\Espressif\tools\ninja\1.12.1;C:\Espressif\tools\idf-exe\1.0.3;%PATH%
echo PATH_SET >> C:\Users\ruv\idf_test.txt
cd /d "%~dp0"
echo CD_DONE >> C:\Users\ruv\idf_test.txt
python %IDF_PATH%\tools\idf.py set-target esp32
if errorlevel 1 goto :fail
python %IDF_PATH%\tools\idf.py build
if errorlevel 1 goto :fail
goto :success
:fail
echo BUILD_FAILED >> C:\Users\ruv\idf_test.txt
goto :eof
:success
echo BUILD_SUCCEEDED >> C:\Users\ruv\idf_test.txt >> C:\Users\ruv\idf_test.txt 2>&1
echo RC=%ERRORLEVEL% >> C:\Users\ruv\idf_test.txt
