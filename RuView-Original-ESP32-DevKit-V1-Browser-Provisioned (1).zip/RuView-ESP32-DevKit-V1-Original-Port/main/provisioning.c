#include "provisioning.h"

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_wifi.h"
#include "esp_http_server.h"
#include "nvs.h"
#include "nvs_flash.h"

#define SETUP_AP_SSID "RuView-ESP32-Setup"
#define SETUP_AP_PASSWORD "ruview1234"
#define SETUP_AP_CHANNEL 6
#define SETUP_AP_IP "192.168.4.1"
#define SETUP_DEFAULT_PORT 5005
#define SETUP_DEFAULT_CHANNEL 0

static const char *TAG = "provisioning";
static httpd_handle_t s_server;

bool ruview_provisioning_has_saved_config(void)
{
    nvs_handle_t h;
    esp_err_t err = nvs_open("csi_cfg", NVS_READONLY, &h);
    if (err != ESP_OK) return false;

    char ssid[33] = {0};
    size_t len = sizeof(ssid);
    err = nvs_get_str(h, "ssid", ssid, &len);
    nvs_close(h);
    return err == ESP_OK && ssid[0] != '\0';
}

static int hex_value(char c)
{
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

static void url_decode(char *s)
{
    char *src = s;
    char *dst = s;
    while (*src) {
        if (*src == '+') {
            *dst++ = ' ';
            src++;
        } else if (*src == '%' && isxdigit((unsigned char)src[1]) &&
                   isxdigit((unsigned char)src[2])) {
            int hi = hex_value(src[1]);
            int lo = hex_value(src[2]);
            *dst++ = (char)((hi << 4) | lo);
            src += 3;
        } else {
            *dst++ = *src++;
        }
    }
    *dst = '\0';
}

static bool form_value(const char *body, const char *key, char *out, size_t out_len)
{
    char needle[64];
    snprintf(needle, sizeof(needle), "%s=", key);
    const char *p = strstr(body, needle);
    if (!p || (p != body && p[-1] != '&')) return false;
    p += strlen(needle);

    size_t n = 0;
    while (p[n] && p[n] != '&') n++;
    if (n >= out_len) return false;
    memcpy(out, p, n);
    out[n] = '\0';
    url_decode(out);
    return true;
}

static bool valid_ipv4(const char *ip)
{
    int a, b, c, d;
    char tail;
    if (sscanf(ip, "%d.%d.%d.%d%c", &a, &b, &c, &d, &tail) != 4) return false;
    return a >= 0 && a <= 255 && b >= 0 && b <= 255 &&
           c >= 0 && c <= 255 && d >= 0 && d <= 255;
}

static esp_err_t send_page(httpd_req_t *req, const char *message)
{
    const char *msg = message ? message : "";
    char html[6200];
    int n = snprintf(html, sizeof(html),
        "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>RuView ESP32 Setup</title><style>body{font-family:system-ui;margin:0;background:#111;color:#eee}"
        ".box{max-width:520px;margin:30px auto;padding:24px;background:#1d1d1d;border-radius:18px}"
        "h1{font-size:24px}label{display:block;margin-top:14px}input{width:100%%;box-sizing:border-box;padding:12px;margin-top:6px;border-radius:9px;border:1px solid #555;background:#111;color:#fff}"
        "button{width:100%%;padding:13px;margin-top:20px;border:0;border-radius:10px;font-size:16px}small{color:#aaa}.ok{padding:10px;background:#234d2a;border-radius:8px}"
        "</style></head><body><div class='box'><h1>RuView ESP32 Setup</h1>"
        "<p>Connect this ESP32 to your Android hotspot. Enter the phone hotspot details below.</p>"
        "%s"
        "<form method='post' action='/save'>"
        "<label>Android Hotspot SSID<input name='ssid' maxlength='32' required></label>"
        "<label>Wi-Fi Password<input name='password' maxlength='64' type='password'></label>"
        "<label>Android Phone IP<input name='target_ip' value='192.168.43.1' maxlength='15' required></label>"
        "<label>UDP Port<input name='target_port' value='%d' type='number' min='1024' max='65535' required></label>"
        "<label>CSI Channel (0 = auto)<input name='channel' value='%d' type='number' min='0' max='13'></label>"
        "<small>For many Android hotspots the phone gateway is 192.168.43.1, but verify it on your phone.</small>"
        "<button type='submit'>Save &amp; Reboot</button></form></div></body></html>",
        msg, SETUP_DEFAULT_PORT, SETUP_DEFAULT_CHANNEL);

    if (n < 0 || n >= (int)sizeof(html)) return ESP_ERR_NO_MEM;
    httpd_resp_set_type(req, "text/html; charset=utf-8");
    return httpd_resp_send(req, html, n);
}

static esp_err_t root_handler(httpd_req_t *req)
{
    return send_page(req, NULL);
}

static esp_err_t save_handler(httpd_req_t *req)
{
    if (req->content_len <= 0 || req->content_len > 2048) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid form data");
        return ESP_OK;
    }

    char body[2049] = {0};
    int got = httpd_req_recv(req, body, req->content_len);
    if (got <= 0 || got >= (int)sizeof(body)) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Could not read form");
        return ESP_OK;
    }
    body[got] = '\0';

    char ssid[33] = {0};
    char password[65] = {0};
    char target_ip[16] = {0};
    char port_text[8] = {0};
    char channel_text[4] = {0};

    if (!form_value(body, "ssid", ssid, sizeof(ssid)) || ssid[0] == '\0' ||
        !form_value(body, "target_ip", target_ip, sizeof(target_ip)) ||
        !valid_ipv4(target_ip) ||
        !form_value(body, "target_port", port_text, sizeof(port_text))) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Check SSID, phone IP and UDP port");
        return ESP_OK;
    }
    form_value(body, "password", password, sizeof(password));
    form_value(body, "channel", channel_text, sizeof(channel_text));

    long port = strtol(port_text, NULL, 10);
    long channel = channel_text[0] ? strtol(channel_text, NULL, 10) : 0;
    if (port < 1024 || port > 65535 || channel < 0 || channel > 13) {
        httpd_resp_send_err(req, HTTPD_400_BAD_REQUEST, "Invalid port or channel");
        return ESP_OK;
    }

    nvs_handle_t h;
    esp_err_t err = nvs_open("csi_cfg", NVS_READWRITE, &h);
    if (err == ESP_OK) err = nvs_set_str(h, "ssid", ssid);
    if (err == ESP_OK) err = nvs_set_str(h, "password", password);
    if (err == ESP_OK) err = nvs_set_str(h, "target_ip", target_ip);
    if (err == ESP_OK) err = nvs_set_u16(h, "target_port", (uint16_t)port);
    if (err == ESP_OK) {
        if (channel == 0) {
            err = nvs_erase_key(h, "csi_channel");
            if (err == ESP_ERR_NVS_NOT_FOUND) err = ESP_OK;
        } else {
            err = nvs_set_u8(h, "csi_channel", (uint8_t)channel);
        }
    }
    if (err == ESP_OK) err = nvs_commit(h);
    nvs_close(h);

    if (err != ESP_OK) {
        ESP_LOGE(TAG, "Failed to save config: %s", esp_err_to_name(err));
        httpd_resp_send_err(req, HTTPD_500_INTERNAL_SERVER_ERROR, "NVS save failed");
        return ESP_OK;
    }

    ESP_LOGI(TAG, "Browser provisioning saved SSID=<configured>, target=%s:%ld, channel=%ld",
             target_ip, port, channel);

    httpd_resp_set_type(req, "text/html; charset=utf-8");
    const char *html =
        "<!doctype html><html><head><meta name='viewport' content='width=device-width,initial-scale=1'>"
        "<title>RuView Saved</title></head><body style='font-family:system-ui;padding:24px'>"
        "<h2>Saved successfully</h2><p>ESP32 is rebooting now. Connect your Android phone back to its hotspot.</p>"
        "<p>UDP target: <b>saved</b></p></body></html>";
    httpd_resp_send(req, html, HTTPD_RESP_USE_STRLEN);
    vTaskDelay(pdMS_TO_TICKS(700));
    esp_restart();
    return ESP_OK;
}

int ruview_provisioning_start(void)
{
    ESP_ERROR_CHECK(esp_netif_init());
    esp_err_t event_err = esp_event_loop_create_default();
    if (event_err != ESP_OK && event_err != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "event loop init failed: %s", esp_err_to_name(event_err));
        return event_err;
    }

    esp_netif_t *ap_netif = esp_netif_create_default_wifi_ap();
    if (!ap_netif) {
        ESP_LOGE(TAG, "failed to create AP netif");
        return ESP_FAIL;
    }

    wifi_init_config_t wifi_cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&wifi_cfg));

    wifi_config_t ap_cfg = {
        .ap = {
            .ssid = SETUP_AP_SSID,
            .ssid_len = strlen(SETUP_AP_SSID),
            .channel = SETUP_AP_CHANNEL,
            .password = SETUP_AP_PASSWORD,
            .max_connection = 4,
            .authmode = WIFI_AUTH_WPA2_PSK,
        },
    };

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_AP));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_AP, &ap_cfg));
    ESP_ERROR_CHECK(esp_wifi_start());

    httpd_config_t config = HTTPD_DEFAULT_CONFIG();
    config.server_port = 80;
    config.max_uri_handlers = 8;
    config.stack_size = 6144;

    esp_err_t err = httpd_start(&s_server, &config);
    if (err != ESP_OK) {
        ESP_LOGE(TAG, "HTTP server start failed: %s", esp_err_to_name(err));
        return err;
    }

    httpd_uri_t root = {.uri = "/", .method = HTTP_GET, .handler = root_handler, .user_ctx = NULL};
    httpd_uri_t save = {.uri = "/save", .method = HTTP_POST, .handler = save_handler, .user_ctx = NULL};
    httpd_register_uri_handler(s_server, &root);
    httpd_register_uri_handler(s_server, &save);

    ESP_LOGI(TAG, "====================================================");
    ESP_LOGI(TAG, "FIRST-BOOT PROVISIONING MODE");
    ESP_LOGI(TAG, "Wi-Fi AP : %s", SETUP_AP_SSID);
    ESP_LOGI(TAG, "Password : %s", SETUP_AP_PASSWORD);
    ESP_LOGI(TAG, "Open     : http://%s", SETUP_AP_IP);
    ESP_LOGI(TAG, "====================================================");
    return ESP_OK;
}
