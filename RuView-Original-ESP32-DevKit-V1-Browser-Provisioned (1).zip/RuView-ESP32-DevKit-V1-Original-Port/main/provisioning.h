#ifndef RUVIEW_PROVISIONING_H
#define RUVIEW_PROVISIONING_H

#include <stdbool.h>

/**
 * First-boot browser provisioning over a temporary SoftAP.
 * Returns ESP_OK when the setup AP and web server are running.
 */
int ruview_provisioning_start(void);

/** True when the csi_cfg NVS namespace contains a saved Wi-Fi SSID. */
bool ruview_provisioning_has_saved_config(void);

#endif
