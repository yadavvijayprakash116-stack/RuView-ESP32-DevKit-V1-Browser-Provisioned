# RuView: phone 3D Observatory setup

## Architecture

ESP32 DevKit V1 -> Wi-Fi CSI -> UDP :5005 -> RuView sensing-server -> HTTP/WebSocket -> phone browser

The phone does not need to receive CSI packets directly. Keep the sensing-server on a PC or Raspberry Pi on the same LAN as the ESP32 and phone.

## Start the sensing server

From the RuView repository's `v2` directory:

```bash
cargo run -p wifi-densepose-sensing-server -- \
  --source esp32 \
  --udp-port 5005 \
  --http-port 3000 \
  --ws-port 3001 \
  --ui-path ../../ui
```

Or use the official Docker image:

```bash
docker run --rm \
  -e CSI_SOURCE=esp32 \
  -p 3000:3000 \
  -p 3001:3001 \
  -p 5005:5005/udp \
  ruvnet/wifi-densepose:latest
```

## Open the 3D Observatory on the phone

Find the LAN IP of the computer running `sensing-server`. For example, if it is `192.168.1.20`, open:

```text
http://192.168.1.20:3000/ui/observatory.html
```

The Observatory uses the sensing-server's WebSocket stream. When live ESP32 data is available, the UI can switch from demo data to live data.

## Quick checks on the host

```text
http://<HOST-IP>:3000/health
http://<HOST-IP>:3000/api/v1/nodes
http://<HOST-IP>:3000/api/v1/sensing/latest
```

## Important

This ESP32 DevKit V1 firmware is an experimental port. The GitHub build only proves that the source compiles for the selected ESP32 target; it does not prove CSI quality or the 3D visualization until the physical board sends valid frames to the sensing-server.
